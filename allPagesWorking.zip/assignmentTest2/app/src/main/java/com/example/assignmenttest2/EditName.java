package com.example.assignmenttest2;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class EditName extends Activity {
    private String newProfileName = "";
    private EditText editName;
    private Button updateButton;
    private String saved = "Saved";
    DataHolder data = new DataHolder();


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_name);


        editName = findViewById(R.id.editText);
        updateButton = findViewById(R.id.updateNameBtn);
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newProfileName = editName.getText().toString();
                data.setData(newProfileName);
                Toast.makeText(EditName.this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
