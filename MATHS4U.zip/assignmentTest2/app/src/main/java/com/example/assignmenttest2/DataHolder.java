package com.example.assignmenttest2;

import android.app.Application;


public class DataHolder {
    private static String data;
    public static String getData() {return data;}
    public static void setData(String data) {DataHolder.data = data;}
}