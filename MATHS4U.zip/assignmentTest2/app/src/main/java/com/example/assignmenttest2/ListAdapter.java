package com.example.assignmenttest2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ListViewHolder> {
private Button startButton;
    ArrayList<String> difficulties = new ArrayList<String>() {
        {
            add("Level 1");
            add("Level 2");
            add("Level 3");
            add("Level 4");
            add("Level 5");
            add("Level 6");
            add("Level 7");
            add("Level 8");
            add("Level 9");
            add("Level 10");
            add("Level 11");
            add("Level 12");


        }
    };
    ArrayList<String> descriptions = new ArrayList<String>() {
        {
            add("For students in Kindergarten to Year 1");
            add("For students in Years 1 to 2");
            add("For students in Years 2 to 3");
            add("For students in Years 3 to 4");
            add("For students in Years 4 to 5");
            add("For students in Years 5 to 6");
            add("For students in Years 6 to 7");
            add("For students in Years 7 to 8");
            add("For students in Years 8 to 9");
            add("For students in Years 9 to 10");
            add("For students in Years 10 to 11");
            add("For students in Years 11 to 12");


        }
    };
    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_adapter, parent, false);


        ListViewHolder listViewHolder = new ListViewHolder(view);
        startButton = view.findViewById(R.id.StartButton);
        return listViewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {

        holder.quizTitle.setText(difficulties.get(position));
        holder.quizDescription.setText(descriptions.get(position));

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();
                Intent intent = new Intent(context, QuizGame.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return difficulties.size();
    }


    public static class ListViewHolder extends RecyclerView.ViewHolder {
        public View view;
        public TextView quizTitle;
        public TextView quizDescription;
        public Button startButton;


        public ListViewHolder(View v) {
            super(v);
            view = v;
            quizTitle = v.findViewById(R.id.QuizName);
            quizDescription = v.findViewById(R.id.QuizDescription);
            startButton = v.findViewById(R.id.StartButton);
        }
    }
}