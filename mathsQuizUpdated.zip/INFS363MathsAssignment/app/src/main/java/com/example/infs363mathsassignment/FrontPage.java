package com.example.infs363mathsassignment;

public class FrontPage {



}
